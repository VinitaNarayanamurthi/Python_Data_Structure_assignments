"""
CSCI-603 Parser Lab
Author: Sean Strout @ RIT CS

A custom exception class for representing a runtime error.
"""

class RuntimeError(Exception):
    pass